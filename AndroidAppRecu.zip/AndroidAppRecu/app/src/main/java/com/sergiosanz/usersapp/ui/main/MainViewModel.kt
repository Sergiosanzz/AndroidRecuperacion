package com.sergiosanz.usersapp.ui.main

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sergiosanz.usersapp.data.User
import com.sergiosanz.usersapp.repositories.LoadUsers
import kotlinx.coroutines.launch

class MainViewModel:ViewModel() {

    private val loadUsers= LoadUsers()

    var isLoading by mutableStateOf(true)

    var users by mutableStateOf<List<User>?>(null)
    var error by mutableStateOf<String?>(null)

    fun loadUsers()=viewModelScope.launch{
        loadUsers.loadUsers{

            isLoading=false

            it.onSuccess {
                users=it
            }


            it.onFailure {
                error=it.message
            }

        }
    }

    init {
        loadUsers()
    }


}