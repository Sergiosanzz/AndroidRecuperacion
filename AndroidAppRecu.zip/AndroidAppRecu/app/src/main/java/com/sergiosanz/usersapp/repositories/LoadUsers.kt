package com.sergiosanz.usersapp.repositories

import com.sergiosanz.usersapp.data.User
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class LoadUsers {

    private val baseUrl="https://dummyjson.com"

    private val retrofit=Retrofit.Builder().baseUrl(baseUrl)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val service=retrofit.create(LoadUsersAPI::class.java)

    suspend fun loadUsers(result:(Result<List<User>>)->Unit){
        val response=service.loadUsers()

        if (response.isSuccessful){
            val users=response.body()?.users ?: emptyList()
            result(Result.success(users))
        }else{
            val error=Throwable(response.message())
            result(Result.failure(error))
        }

    }

    suspend fun loadUser(id:Int,result:(Result<User?>)->Unit) {
        val response = service.loadUser(id)

        if (response.isSuccessful) {
            val user = response.body()
            result(Result.success(user))
        } else {
            val error = Throwable(response.message())
            result(Result.failure(error))
        }
    }

}