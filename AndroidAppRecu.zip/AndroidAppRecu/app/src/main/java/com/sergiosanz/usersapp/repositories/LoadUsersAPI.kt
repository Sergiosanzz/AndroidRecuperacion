package com.sergiosanz.usersapp.repositories

import com.sergiosanz.usersapp.data.User
import com.sergiosanz.usersapp.data.UsersResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface LoadUsersAPI {

    @GET("/users")
    suspend fun loadUsers():Response<UsersResponse>

    @GET("/users/{id}")
    suspend fun loadUser(@Path("id") id:Int):Response<User>

}