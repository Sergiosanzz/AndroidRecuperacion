package com.sergiosanz.usersapp.ui.userInfo

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.sergiosanz.usersapp.CenterProgress
import com.sergiosanz.usersapp.ErrorMessage
import com.sergiosanz.usersapp.data.User
import com.sergiosanz.usersapp.ui.theme.UsersAppTheme

class UserInfoActivity:ComponentActivity() {

    private val vm by viewModels<UserInfoViewModel>()

    @OptIn(ExperimentalMaterial3Api::class)
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            UsersAppTheme {

                Scaffold(
                    content = {
                        Content()
                    },
                    topBar = {
                        CenterAlignedTopAppBar (
                            title={
                                Text(text = "User Info")
                            },
                            navigationIcon = {
                                IconButton(onClick = { finish() }) {
                                    Icon(Icons.Default.ArrowBack,null)
                                }
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary,
                                navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                            )
                        )
                    }
                )

            }

        }

        val id=intent.getIntExtra("id",0)
        vm.loadUser(id)

    }

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @Composable
    fun Content() {

        if (vm.user!=null)
            UserInfo(user = vm.user!!)
        else{

            if (vm.isLoading){
                CenterProgress()
                return
            }

            if (vm.error!=null){
                ErrorMessage(message = vm.error?:"Try again later")
                return
            }

        }
    }

    @Composable
    fun UserInfo(user:User) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            AsyncImage(
                model = user.image,
                contentDescription = null,
                modifier = Modifier
                    .size(150.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = user.firstName+" "+user.lastName, fontSize = 20.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(12.dp))


            Text(text = "Company name: ${user.company.name}")


        }
    }

}