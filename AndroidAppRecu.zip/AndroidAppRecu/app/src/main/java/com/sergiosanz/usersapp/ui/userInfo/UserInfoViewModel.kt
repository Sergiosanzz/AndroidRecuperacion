package com.sergiosanz.usersapp.ui.userInfo

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sergiosanz.usersapp.data.User
import com.sergiosanz.usersapp.repositories.LoadUsers
import kotlinx.coroutines.launch

class UserInfoViewModel: ViewModel() {

    private val loadUser= LoadUsers()

    var isLoading by mutableStateOf(true)

    var user by mutableStateOf<User?>(null)
    var error by mutableStateOf<String?>(null)


    fun loadUser(id:Int)=viewModelScope.launch {
        loadUser.loadUser(id){
            isLoading=false

            it.onSuccess {
                user=it
            }


            it.onFailure {
                error=it.message
            }

        }
    }

}