package com.sergiosanz.usersapp.ui.main

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Space
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.sergiosanz.usersapp.CenterProgress
import com.sergiosanz.usersapp.ErrorMessage
import com.sergiosanz.usersapp.data.User
import com.sergiosanz.usersapp.ui.theme.UsersAppTheme
import com.sergiosanz.usersapp.ui.userInfo.UserInfoActivity
import com.sergiosanz.usersapp.ui.userInfo.UserInfoViewModel
import java.net.ContentHandler

class MainActivity : ComponentActivity() {

    private val vm by viewModels<MainViewModel>()

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UsersAppTheme {
                Scaffold (
                    topBar = {
                        CenterAlignedTopAppBar (
                            title={
                                Text(text = "Users")
                            },
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                titleContentColor = MaterialTheme.colorScheme.onPrimary,
                                navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                            )
                        )
                    },
                    content = {
                        Content()
                    }
                )
            }
        }
    }


    @Composable
    fun Content() {
        if (vm.users!=null){
            UsersList(
                users=vm.users?: emptyList(),
                onUserClicked={
                    val intent=Intent(this,UserInfoActivity::class.java)
                    intent.putExtra("id",it)
                    startActivity(intent)
                }
            )
        }else{

            if (vm.isLoading){
                CenterProgress()
                return
            }

            if (vm.error!=null){
                ErrorMessage(message = vm.error ?: "Try again later")
            }

        }

    }

    @Composable
    fun UsersList(
        users:List<User>,
        onUserClicked:(Int)->Unit
    ) {

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(12.dp)
        ){
            item {
                Spacer(modifier = Modifier.height(55.dp))
            }
            items(users){
                UserItem(user = it) {
                    onUserClicked(it.id)
                }
            }
        }

    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun UserItem(
        user:User,
        onClick:()->Unit
    ) {
        Card(
            onClick={
                onClick()
            }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(model = user.image, contentDescription = null, modifier = Modifier.size(70.dp))
                Text(text = user.firstName + " " + user.lastName)
            }
        }
    }

}
